self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "580613d4e9e7bcbf11c1",
    "url": "/css/about.cd271255.css"
  },
  {
    "revision": "e93c9eb1e85329dff412",
    "url": "/css/account.1a6e34ae.css"
  },
  {
    "revision": "db9111365fba1ac96062",
    "url": "/css/app.6a209964.css"
  },
  {
    "revision": "1c2027a80caeee7c0650",
    "url": "/css/chunk-vendors.d8216893.css"
  },
  {
    "revision": "c54209bfa7b6bfbcb075",
    "url": "/css/email.68786e50.css"
  },
  {
    "revision": "e0231549dfd99cf99ef0",
    "url": "/css/error.49edf2a3.css"
  },
  {
    "revision": "e9603682436562424dbf",
    "url": "/css/garden.1968803e.css"
  },
  {
    "revision": "beb76de0e1b20ba4bd03",
    "url": "/css/mitax.058d6fd2.css"
  },
  {
    "revision": "4042faef1c31aad26c73",
    "url": "/css/steamer.cc467bd4.css"
  },
  {
    "revision": "ac881fc61538a9928e9ec99f95abdba3",
    "url": "/img/about.ac881fc6.png"
  },
  {
    "revision": "2bd719d9dde46c3db11e91cbf6db3c25",
    "url": "/img/acc01.2bd719d9.jpg"
  },
  {
    "revision": "8d68c1209def694812e15ee8f672af75",
    "url": "/img/acc02.8d68c120.jpg"
  },
  {
    "revision": "719d4144ced870113ccedc9a5e9226c1",
    "url": "/img/acc03.719d4144.jpg"
  },
  {
    "revision": "db17102a220bee2ffb79bebfd34ae3df",
    "url": "/img/acc04.db17102a.jpg"
  },
  {
    "revision": "907b9faba8ab772a22ba8951443fdfa5",
    "url": "/img/agency.907b9fab.jpg"
  },
  {
    "revision": "c4466868f3341765b4353cbc1e54ef75",
    "url": "/img/arrow-l.c4466868.png"
  },
  {
    "revision": "9a6ebdc827f2540fe4fc53a35191523a",
    "url": "/img/arrow-r.9a6ebdc8.png"
  },
  {
    "revision": "57172435b9c590e1c518d70ed0f6ed80",
    "url": "/img/banner.57172435.jpg"
  },
  {
    "revision": "669ccd08952852c71157bfdba38d456e",
    "url": "/img/cancel.669ccd08.png"
  },
  {
    "revision": "b043b2b9b1ec6c31c29dd62e66cfe452",
    "url": "/img/cancel2.b043b2b9.png"
  },
  {
    "revision": "800b26fa1e36241d31d7da40e7adc191",
    "url": "/img/card01.800b26fa.jpg"
  },
  {
    "revision": "facad14a9d76723fba8169ca433b33bc",
    "url": "/img/card02.facad14a.jpg"
  },
  {
    "revision": "60d836266d5c69c8f35eb3906963662e",
    "url": "/img/card03.60d83626.jpg"
  },
  {
    "revision": "9e724499647fcd10ac389f61541e5386",
    "url": "/img/choose.9e724499.jpg"
  },
  {
    "revision": "03a81c401511bb916f335f55c3179ad1",
    "url": "/img/circle.03a81c40.png"
  },
  {
    "revision": "ea4a111e11287ed93aa1f6f0c53fb718",
    "url": "/img/connect.ea4a111e.jpg"
  },
  {
    "revision": "04fb43ae095d19b498e72fd13107deaa",
    "url": "/img/coop01.04fb43ae.jpg"
  },
  {
    "revision": "f1376a88ddd24e9564bce71c8fe12296",
    "url": "/img/coop02.f1376a88.jpg"
  },
  {
    "revision": "df4b66a6febe59765a669271d55be1ac",
    "url": "/img/coop03.df4b66a6.jpg"
  },
  {
    "revision": "f16b111e0e63b55b3b5bf3b4b8b50297",
    "url": "/img/coop04.f16b111e.jpg"
  },
  {
    "revision": "4aada20065943caf148fff8e799ed2a7",
    "url": "/img/coop05.4aada200.jpg"
  },
  {
    "revision": "1e17e789b4c8b9d54bda97e761cb9e2c",
    "url": "/img/coop06.1e17e789.jpg"
  },
  {
    "revision": "cde5bcef68cdb3a4c0ea85a0bcfd4c4a",
    "url": "/img/coop07.cde5bcef.jpg"
  },
  {
    "revision": "548a82114c411571d4697516b2376d8b",
    "url": "/img/des01.548a8211.jpg"
  },
  {
    "revision": "d465255a9721ad968203f92fa72ce809",
    "url": "/img/des02.d465255a.jpg"
  },
  {
    "revision": "a478d8ae512eea024b16dcffb70dcb82",
    "url": "/img/des03.a478d8ae.jpg"
  },
  {
    "revision": "2fdd5d1f6fa47c8de352983abc186737",
    "url": "/img/des04.2fdd5d1f.jpg"
  },
  {
    "revision": "6a49e37b93ee6325cd2e94d096c86ef5",
    "url": "/img/des05.6a49e37b.jpg"
  },
  {
    "revision": "6592bbbacd0a7633fd23d4447ac12c4d",
    "url": "/img/des06.6592bbba.jpg"
  },
  {
    "revision": "dc163ec5798465cf6f6a3f7d5bc9f3d3",
    "url": "/img/economy.dc163ec5.jpg"
  },
  {
    "revision": "bbba8365ab6393bcbd4616b2479b17c8",
    "url": "/img/empty.bbba8365.png"
  },
  {
    "revision": "ef3414a266d8b9cbd7fd51cba2cd505e",
    "url": "/img/garden.ef3414a2.jpg"
  },
  {
    "revision": "520629a79ce3e75dedcf9556566b7136",
    "url": "/img/gift.520629a7.png"
  },
  {
    "revision": "d5a0559df58d278e0d617fef31b59ef4",
    "url": "/img/government.d5a0559d.jpg"
  },
  {
    "revision": "82f03a57cc9adb84e7a37d0a19b21706",
    "url": "/img/home2.82f03a57.png"
  },
  {
    "revision": "e9598fdb87f067c14efeeb6c66f33f1a",
    "url": "/img/home3.e9598fdb.png"
  },
  {
    "revision": "ad33119d2e6f0659e47b4ca0391fa98c",
    "url": "/img/home4.ad33119d.png"
  },
  {
    "revision": "679248d5aa9157b458c17c3bfcacbd05",
    "url": "/img/home5.679248d5.png"
  },
  {
    "revision": "9d32ae15aad50c4a80f460b47212cba6",
    "url": "/img/home6.9d32ae15.png"
  },
  {
    "revision": "6db6133694cdb047028b45e6750899b0",
    "url": "/img/home7.6db61336.png"
  },
  {
    "revision": "ac03fb245a35ecd5e4cfe3e6a91b36d5",
    "url": "/img/home8.ac03fb24.png"
  },
  {
    "revision": "7c9de5978bc674fbf997c517a2e59fb4",
    "url": "/img/logo-white.7c9de597.png"
  },
  {
    "revision": "1a50d99dbb8a4d9e6f93868c8031eedc",
    "url": "/img/map.1a50d99d.jpg"
  },
  {
    "revision": "44ac3648b921ce43c1659ec09818fbbf",
    "url": "/img/map.44ac3648.png"
  },
  {
    "revision": "75e10fa6161a84d5c4c68a5212456139",
    "url": "/img/mitax.75e10fa6.jpg"
  },
  {
    "revision": "6a3b7855b06b7a153b81fc58d056ccb5",
    "url": "/img/person.6a3b7855.jpg"
  },
  {
    "revision": "a769deda1a172aa8b53e850a3a9499de",
    "url": "/img/reach.a769deda.jpg"
  },
  {
    "revision": "9b93a598239f7c615f4c35a3907f83e0",
    "url": "/img/steamer.9b93a598.jpg"
  },
  {
    "revision": "aa80fc0c050ead0d0227676bb968992f",
    "url": "/img/wechat.aa80fc0c.png"
  },
  {
    "revision": "9e8e7c055f41cc30c498d153b842b8bc",
    "url": "/index.html"
  },
  {
    "revision": "580613d4e9e7bcbf11c1",
    "url": "/js/about-legacy.d20d621c.js"
  },
  {
    "revision": "e93c9eb1e85329dff412",
    "url": "/js/account-legacy.a29d3b4f.js"
  },
  {
    "revision": "db9111365fba1ac96062",
    "url": "/js/app-legacy.04c6e131.js"
  },
  {
    "revision": "1c2027a80caeee7c0650",
    "url": "/js/chunk-vendors-legacy.e5c5e340.js"
  },
  {
    "revision": "c54209bfa7b6bfbcb075",
    "url": "/js/email-legacy.1cddf9c3.js"
  },
  {
    "revision": "e0231549dfd99cf99ef0",
    "url": "/js/error-legacy.1c7319d5.js"
  },
  {
    "revision": "e9603682436562424dbf",
    "url": "/js/garden-legacy.2e9f7116.js"
  },
  {
    "revision": "beb76de0e1b20ba4bd03",
    "url": "/js/mitax-legacy.7e8082c9.js"
  },
  {
    "revision": "4042faef1c31aad26c73",
    "url": "/js/steamer-legacy.b006f156.js"
  },
  {
    "revision": "dfa23a797b6dc19de20548e352bc023b",
    "url": "/manifest.json"
  }
]);